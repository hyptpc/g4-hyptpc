#include "Constants.hh"
void GetKpAcceptance(){
	bool CH2 = false;
	CH2 = true;
	TFile* file;
	TFile* file2;
	if(CH2){
	 	file = new TFile("../KpCosHist.root");//Input Geant4 file
		file2 = new TFile("KpCosAcceptance.root","recreate");//Output Acceptance file
	}
	else{
	 	file = new TFile("KpUniformHistCarbon.root");
		file2 = new TFile("KpAcceptanceCarbon.root","recreate");
	}
	TH2D* HGen = (TH2D*)file->Get("BeamGenThetaP");
	TH2D* HAcpt = (TH2D*)file->Get("BeamAcptThetaP");
	TH2D* HGenX = (TH2D*)file->Get("BeamGenXThetaP");
	TH2D* HAcptX = (TH2D*)file->Get("BeamAcptXThetaP");
	TH2D* HGenY = (TH2D*)file->Get("BeamGenYThetaP");
	TH2D* HAcptY = (TH2D*)file->Get("BeamAcptYThetaP");
	TH2D* HGenPhi = (TH2D*)file->Get("BeamGenPhiP");
	TH2D* HAcptPhi = (TH2D*)file->Get("BeamAcptPhiP");
	TTree* tree = new TTree("tree","tree");
	int nbx = HGen->GetNbinsX();
	int nby = HGen->GetNbinsY();
	double bwTheta = HGen->GetXaxis()->GetBinWidth(1);
	double Theta0 = HGen->GetXaxis()->GetXmin();
	double Theta1 = HGen->GetXaxis()->GetXmax();
	double bwP = HGen->GetYaxis()->GetBinWidth(1);
	double P0 = HGen->GetYaxis()->GetXmin();
	double P1 = HGen->GetYaxis()->GetXmax();
	double theta,P,gen,acpt,eff;
	int nbxX = HGenX->GetNbinsX();
	int nbxY = HGenY->GetNbinsX();
	double bwThetaX = HGenX->GetXaxis()->GetBinWidth(1);
	double bwThetaY = HGenY->GetXaxis()->GetBinWidth(1);
	double Theta0X = HGenX->GetXaxis()->GetXmin();
	double Theta1X = HGenX->GetXaxis()->GetXmax();
	double Theta0Y = HGenY->GetXaxis()->GetXmin();
	double Theta1Y = HGenY->GetXaxis()->GetXmax();

	int nbxPhi = HGenPhi->GetNbinsX();
	int nbyPhi = HGenPhi->GetNbinsY();
	double bwPhi = HGenPhi->GetXaxis()->GetBinWidth(1);
	double Phi0 = HGenPhi->GetXaxis()->GetXmin();
	double Phi1 = HGenPhi->GetXaxis()->GetXmax();
	double bwPPhi = HGenPhi->GetYaxis()->GetBinWidth(1);
	double P0Phi = HGenPhi->GetYaxis()->GetXmin();
	double P1Phi = HGenPhi->GetYaxis()->GetXmax();


	cout<<Form("Theta (%g,%g) with %g bin",Theta0,Theta1,bwTheta)<<endl;
	cout<<Form("Mom (%g,%g) with %g bin",P0,P1,bwP)<<endl;
	TH2D* HEff = new TH2D("BeamAcceptance","BeamAcceptance",nbx,Theta0,Theta1,nby,P0,P1);
	TH2D* HEffX = new TH2D("BeamAcceptanceX","BeamAcceptanceX",nbxX,Theta0X,Theta1X,nby,P0,P1);
	TH2D* HEffY = new TH2D("BeamAcceptanceY","BeamAcceptanceY",nbxY,Theta0Y,Theta1Y,nby,P0,P1);
	TH2D* HEffPhi = new TH2D("BeamAcceptancePhi","BeamAcceptancePhi",nbxPhi,Phi0,Phi1,nbyPhi,P0Phi,P1Phi);
	

	tree->Branch("theta",&theta);
	tree->Branch("P",&P);
	tree->Branch("gen",&gen);
	tree->Branch("acpt",&acpt);
	tree->Branch("eff",&eff);
	for(double ith = 1; ith <= nbx; ++ith){
		theta = (ith - 0.5)*bwTheta +Theta0;
		for(double iP = 1; iP <= nby; ++iP){
			P = (iP - 0.5)*bwP +P0;
			gen = HGen->GetBinContent(ith,iP);
			acpt = HAcpt->GetBinContent(ith,iP);
			if(gen == 0) continue;
			eff = acpt / gen;
			HEff->SetBinContent(ith,iP,eff);
			tree->Fill();
		}
	}
	for(double ith = 1; ith <= nbxPhi; ++ith){
		double phi = (ith - 0.5)*bwPhi +Phi0;
		for(double iP = 1; iP <= nbyPhi; ++iP){
			P = (iP - 0.5)*bwPPhi +P0Phi;
			gen = HGenPhi->GetBinContent(ith,iP);
			acpt = HAcptPhi->GetBinContent(ith,iP);
			if(gen == 0) continue;
			eff = acpt / gen;
			HEffPhi->SetBinContent(ith,iP,eff);
		}
	}
	for(double ith = 1; ith <= nbxX; ++ith){
		theta = (ith - 0.5)*bwThetaX +Theta0X;
		for(double iP = 1; iP <= nby; ++iP){
			P = (iP - 0.5)*bwP +P0;
			gen = HGenX->GetBinContent(ith,iP);
			acpt = HAcptX->GetBinContent(ith,iP);
			if(gen == 0) continue;
			eff = acpt / gen;
			HEffX->SetBinContent(ith,iP,eff);
		}
	}
	for(double ith = 1; ith <= nbxY; ++ith){
		theta = (ith - 0.5)*bwThetaY +Theta0Y;
		for(double iP = 1; iP <= nby; ++iP){
			P = (iP - 0.5)*bwP +P0;
			gen = HGenY->GetBinContent(ith,iP);
			acpt = HAcptY->GetBinContent(ith,iP);
			if(gen == 0) continue;
			eff = acpt / gen;
			HEffY->SetBinContent(ith,iP,eff);
		}
	}

	double th_0 = 0;
	double th_1 = 30;
	int nth = 15;
	double dth = (th_1 - th_0) / nth;
	TH2D* HGenZP[100];
	TH2D* HAcptZP[100];
	TH1D* HGenZ[100];
	TH1D* HAcptZ[100];
	TH1D* HEffZ[100];
	cout<<"ZP"<<endl;
	for(int i = 0; i < nth; ++i){
		double th0 = th_0 + i*dth;
		double th1 = th_0 + (i+1)*dth;
		HGenZP[i] = (TH2D*)file->Get(Form("BeamGenZP_th_%g_%g",th0,th1));
		HAcptZP[i] = (TH2D*)file->Get(Form("BeamAcptZP_th_%g_%g",th0,th1));
		HGenZ[i] = HGenZP[i]->ProjectionX(Form("GenZ_th_%g_%g",th0,th1));
		HAcptZ[i] = HAcptZP[i]->ProjectionX(Form("AcptZ_th_%g_%g",th0,th1));
	}
	cout<<"ZP"<<endl;

	int nbx_Z = HGenZ[0]->GetNbinsX();
	int nby_Z = HGenZ[0]->GetNbinsY();
	double bwZ = HGenZ[0]->GetXaxis()->GetBinWidth(1);
	double Z0 = HGenZ[0]->GetXaxis()->GetXmin();
	double Z1 = HGenZ[0]->GetXaxis()->GetXmax();

	for(int i = 0; i < nth; ++i){
		double th0 = th_0 + i*dth;
		double th1 = th_0 + (i+1)*dth;
		HEffZ[i] = new TH1D(Form("BeamAcceptanceZ_th_%g_%g",th0,th1),Form("BeamAcceptanceZ_th_%g_%g",th0,th1),nbx_Z,Z0,Z1);	
		for(double iZ = 1; iZ <= nby_Z; ++iZ){
			double Z = (iZ - 0.5)*bwZ +Z0;
			double gen = HGenZ[i]->GetBinContent(iZ);
			double acpt = HAcptZ[i]->GetBinContent(iZ);
			if(gen == 0) continue;
			double eff = acpt / gen;
			HEffZ[i]->SetBinContent(iZ,eff);
		}

	}

	HGen->Write();
	HAcpt->Write();
	HEff->Write();
	HGenX->Write();
	HAcptX->Write();
	HEffX->Write();
	HGenY->Write();
	HAcptY->Write();
	HEffY->Write();
	HGenPhi->Write();
	HAcptPhi->Write();
	HEffPhi->Write();
	for(int i = 0; i < nth; ++i){
		HGenZP[i]->Write();
		HAcptZP[i]->Write();
		HGenZ[i]->Write();
		HAcptZ[i]->Write();
		HEffZ[i]->Write();
	}
	TCanvas* c1 = new TCanvas("c1","c1",1200,600);
	c1->Divide(2,1); c1->cd(1);
	HGen->Draw("colz");
	c1->cd(2);
	HAcpt->Draw("colz");
	TCanvas* c2 = new TCanvas("c2","c2",600,600);
	HEff->Draw("colz");
	HEff->GetXaxis()->SetTitle("K^{+} cos(#theta)");
	HEff->GetYaxis()->SetTitle("K^{+} Momemtum[GeV/c]");
	c2->SaveAs("Acceptance.png");
	TCanvas* c3 = new TCanvas("c3","c3",1800,1400);
	c3->Divide(5,3);
	for(int i = 0; i < nth; ++i){
		c3->cd(i+1);
		HEffZ[i]->Draw();
	}
	for(int i = 0; i < nth; ++i){
		HAcptZ[i]->GetXaxis()->SetTitle("Z[cm]");
		HAcptZ[i]->GetYaxis()->SetTitle("Counts");
		HAcptZ[i]->GetXaxis()->SetRangeUser(HAcptZ[i]->GetXaxis()->GetXmin()-20,HAcptZ[i]->GetXaxis()->GetXmax()+20);
		HAcptZ[i]->GetYaxis()->SetRangeUser(0,1.1*HAcptZ[i]->GetMaximum());
	}
	TH1D* HAcptNorm[100];
	for(int i = 0; i < nth; ++i){
		double th0 = th_0 + i*dth;
		double th1 = th_0 + (i+1)*dth;
		int ent =HAcptZ[i]->GetEntries();
		if(ent!= 0)HAcptZ[i]->Scale(1.0/ent);
		HAcptNorm[i] = (TH1D*)HAcptZ[i]->Clone(Form("AcptNorm_th_%g_%g",th0,th1));
	}
	TCanvas* c4 = new TCanvas("c4","c4",1800,1400);
	c4->Divide(5,3);
	for(int i=0;i<nth;++i){
		c4->cd(i+1);
		int ent =HAcptNorm[i]->GetEntries();
		HAcptNorm[i]->Draw();
		HAcptNorm[i]->GetXaxis()->SetTitle("Z[cm]");
		HAcptNorm[i]->GetYaxis()->SetTitle("Normalized Counts");
		double xCenter = HAcptNorm[i]->GetXaxis()->GetXmin() + 0.5*(HAcptNorm[i]->GetXaxis()->GetXmax() - HAcptNorm[i]->GetXaxis()->GetXmin());	
		double yCenter = 0.5*HAcptNorm[i]->GetMaximum();
		if(yCenter == 0) yCenter = 0.5;
		TLatex* tex = new TLatex( xCenter,yCenter,Form("#theta_{K^{+}}(%g,%g) ",i*dth,(i+1)*dth));
		tex->Draw();
		HAcptNorm[i]->Write();
	}
	double p_low = 400;
	double p_high = 2000;
	double dp = 50;
	int np = (p_high - p_low) / dp;
	TH2D* HGenThPh[100];
	TH2D* HAcptThPh[100];
	TH2D* HEffThPh[100];
	cout<<"ThPh"<<endl;	
	for(int ip=0;ip<np;++ip){
		double p0 = p_low + ip*dp;
		double p1 = p_low + (ip+1)*dp;
		TString GenName = Form("BeamGenThPh_P_%d_%d",(int)p0,(int)p1);
		TString AcptName = Form("BeamAcptThPh_P_%d_%d",(int)p0,(int)p1);
		cout<<GenName<<endl;
		cout<<AcptName<<endl;
		HGenThPh[ip] = (TH2D*)file->Get(GenName);
		HAcptThPh[ip] = (TH2D*)file->Get(AcptName);
		int nbx_ThPh = HGenThPh[ip]->GetNbinsX();
		int nby_ThPh = HGenThPh[ip]->GetNbinsY();
		double bwTh = HGenThPh[ip]->GetXaxis()->GetBinWidth(1);
		double Th0 = HGenThPh[ip]->GetXaxis()->GetXmin();
		double Th1 = HGenThPh[ip]->GetXaxis()->GetXmax();
		double bwPh = HGenThPh[ip]->GetYaxis()->GetBinWidth(1);
		double Ph0 = HGenThPh[ip]->GetYaxis()->GetXmin();
		double Ph1 = HGenThPh[ip]->GetYaxis()->GetXmax();
		HEffThPh[ip] = new TH2D(Form("BeamAcceptanceThPh_P_%g_%g",p0,p1),Form("BeamAcceptanceThPhP_%g_%g",p0,p1),nbx_ThPh,Th0,Th1,nby_ThPh,Ph0,Ph1);	
		for(double ith = 1; ith <= nbx_ThPh; ++ith){
			double theta = (ith - 0.5)*bwTh +Th0;
			for(double iPh = 1; iPh <= nby_ThPh; ++iPh){
				double Ph = (iPh - 0.5)*bwPh +Ph0;
				double gen = HGenThPh[ip]->GetBinContent(ith,iPh);
				double acpt = HAcptThPh[ip]->GetBinContent(ith,iPh);
				if(gen == 0) continue;
				double eff = acpt / gen;
				HEffThPh[ip]->SetBinContent(ith,iPh,eff);
			}
		}	
		HGenThPh[ip]->Write();
		HAcptThPh[ip]->Write();
		HEffThPh[ip]->Write();	
	}
	
	
//	file2->Write();
}
